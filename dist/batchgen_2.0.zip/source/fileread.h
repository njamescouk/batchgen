#define MAXLINE 200

char **file_read (FILE *fp);
int line_count (FILE *fp);

