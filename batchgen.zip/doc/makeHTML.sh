xsltproc -nonet --output batchgen_readme.html /cygdrive/c/cygwin/usr/share/docbook-xsl/html/docbook.xsl batchgen_readme.docbook.xml

