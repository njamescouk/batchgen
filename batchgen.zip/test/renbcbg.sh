mv $1 $(echo $1 | tr BC bg) 
