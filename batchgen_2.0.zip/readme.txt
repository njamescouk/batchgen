
This is version 2.0

The grammar is unchanged, but the generated code exploits the 
new call :label syntax.

Sourceforge's file upload system is now a delight to use.

====================================================================


This is version 1.2 of batchgen

It started life on sourceforge, under the misnomer of batcomp.

Owing to sourceforge's hideously arcane and mediaeval file release
'system' I'm hosting it myself, secure in the knowledge that my 
bandwidth bill is going to be nominal.