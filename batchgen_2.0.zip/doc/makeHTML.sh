set xtrans=C:\bin\docbook\docbook-xsl-1.74.0\xhtml\docbook.xsl
xsltproc -nonet --output batchgen_readme.html %xtrans% batchgen_readme.docbook.xml

